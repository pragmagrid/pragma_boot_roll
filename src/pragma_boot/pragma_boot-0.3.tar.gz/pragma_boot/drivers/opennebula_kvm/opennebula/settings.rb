CREDENTIALS = "oneadmin:e7924d87d503411429a2cd4f72ef264f"
ENDPOINT    = "http://localhost:2633/RPC2"
ONEFLOW_URL = "http://localhost:2474"
USER_AGENT = "PRAGMA"
PUBLIC_NETWORK = "defaultpub"
PUBLIC_NETWORK_LEASES = {
    "163.220.57.209" => "02:00:a3:dc:39:d1",
    "163.220.57.210" => "02:00:a3:dc:39:d2",
    "163.220.57.211" => "02:00:a3:dc:39:d3",
    "163.220.57.212" => "02:00:a3:dc:39:d4",
    "163.220.57.213" => "02:00:a3:dc:39:d5",
}
PRIVATE_BRIDGE = "br0"
LOG_FILE = "/tmp/opennebula_kvm.log"
DATASTORE_ID = 1
# TODO: Think of a better way to assign FQDN dynamically
FQDN = "foobar"
TIMEOUT = 999999
DOMAIN = "aist.go.jp"